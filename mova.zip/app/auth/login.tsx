// app/auth/login.tsx

import { Image, Pressable, Text, TextInput, View } from "react-native";

import { COLORS } from "../../src/constants/colors";

export default function LoginScreen() {
  return (
    <View
      className="flex-1 px-6 justify-center"
      style={{
        backgroundColor: COLORS.background,
      }}
    >
      {/* LOGO */}
      <View className="items-center mb-14">
        <Image
          source={require("../../assets/images/logo.png")}
          className="w-44 h-44"
          resizeMode="contain"
        />
      </View>

      {/* TITLE */}
      <View className="mb-8">
        <Text
          className="text-3xl font-bold mb-2"
          style={{
            color: COLORS.white,
          }}
        >
          Bienvenido
        </Text>

        <Text
          className="text-base"
          style={{
            color: COLORS.muted,
          }}
        >
          Iniciá sesión para continuar
        </Text>
      </View>

      {/* FORM */}
      <View className="gap-4">
        {/* EMAIL */}
        <View>
          <Text
            className="mb-2"
            style={{
              color: COLORS.white,
            }}
          >
            Email
          </Text>

          <TextInput
            placeholder="ejemplo@gmail.com"
            placeholderTextColor={COLORS.muted}
            className="
              rounded-2xl
              px-4
              py-4
              text-base
            "
            style={{
              backgroundColor: COLORS.card,
              borderWidth: 1,
              borderColor: COLORS.border,
              color: COLORS.white,
            }}
          />
        </View>

        {/* PASSWORD */}
        <View>
          <Text
            className="mb-2"
            style={{
              color: COLORS.white,
            }}
          >
            Contraseña
          </Text>

          <TextInput
            secureTextEntry
            placeholder="********"
            placeholderTextColor={COLORS.muted}
            className="
              rounded-2xl
              px-4
              py-4
              text-base
            "
            style={{
              backgroundColor: COLORS.card,
              borderWidth: 1,
              borderColor: COLORS.border,
              color: COLORS.white,
            }}
          />
        </View>

        {/* BUTTON */}
        <Pressable
          className="
            rounded-2xl
            py-4
            items-center
            mt-4
          "
          style={{
            backgroundColor: COLORS.primary,
          }}
        >
          <Text
            className="text-base font-bold"
            style={{
              color: "#000",
            }}
          >
            Ingresar
          </Text>
        </Pressable>
      </View>

      {/* FOOTER */}
      <View className="flex-row justify-center mt-8">
        <Text
          style={{
            color: COLORS.muted,
          }}
        >
          ¿No tenés cuenta?
        </Text>

        <Text
          className="font-semibold ml-2"
          style={{
            color: COLORS.primary,
          }}
        >
          Registrarse
        </Text>
      </View>
    </View>
  );
}